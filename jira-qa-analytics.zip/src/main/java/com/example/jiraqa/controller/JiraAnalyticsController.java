package com.example.jiraqa.controller;

public class JiraAnalyticsController {}