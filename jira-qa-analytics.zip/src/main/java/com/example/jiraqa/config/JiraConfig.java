package com.example.jiraqa.config;

public class JiraConfig {}