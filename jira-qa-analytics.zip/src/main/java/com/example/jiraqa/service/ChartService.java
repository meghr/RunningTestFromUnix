package com.example.jiraqa.service;

public class ChartService {}