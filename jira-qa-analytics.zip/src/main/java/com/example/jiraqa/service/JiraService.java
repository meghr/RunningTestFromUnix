package com.example.jiraqa.service;

public class JiraService {}