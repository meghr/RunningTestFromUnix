package com.example.jiraqa.model;

public class JiraIssue {}